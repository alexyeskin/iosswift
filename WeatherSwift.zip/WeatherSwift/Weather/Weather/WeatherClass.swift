//
//  File.swift
//  Weather
//
//  Created by user on 16/04/2019.
//  Copyright © 2019 Alexander Yeskin. All rights reserved.
//

import Foundation

class Weather {
    static let shared = Weather()
    var 
}
