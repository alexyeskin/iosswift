//
//  SearchCity.swift
//  Weather
//
//  Created by user on 17/04/2019.
//  Copyright © 2019 Alexander Yeskin. All rights reserved.
//

//import Foundation
//
//class SearchCityOLD {
//    static let shared = SearchCityOLD()
//    var cities: [Weather] = []
//    var index: Int?
//    var time: String?
//    var name: String?
//    var t: Int?
//    func createCity(city: String, t: Int, description: String, windSpeed: Int, windDirection: String, feelsT: Int) {
//        cities.append(Weather(city: city, t: t, description: description, windSpeed: windSpeed, windDirection: windDirection, feelsT: feelsT, forecast: ))
//    }
//}
